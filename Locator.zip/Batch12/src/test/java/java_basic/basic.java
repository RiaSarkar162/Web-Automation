package java_basic;

import java.util.Scanner;

public class basic {

	public static void main(String[] args) {
		 Scanner scanner= new Scanner(System.in);
		 System.out.println("Enter First Number");
		 int number1 = scanner.nextInt();
		 
		 System.out.println("Enter Second number");
		 int number2 = scanner.nextInt();
		 
		 System.out.println(number1+number2);
		 
	}

}
 